﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoMVC.Controllers
{
    public class DemoController : Controller
    {
        public IActionResult Home()
        {
            //return RedirectToAction("AboutUs");
            //return "Any string here";
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }
    }
}
