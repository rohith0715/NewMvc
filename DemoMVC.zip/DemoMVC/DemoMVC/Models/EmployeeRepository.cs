﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoMVC.Models
{
    public class EmployeeRepository:IEmployeeRepository
    {
        EmployeeContext _context;
        public EmployeeRepository(EmployeeContext context)
        {
            _context = context;
        }

        public List<Employee> ViewEmployee()
        {
            return _context.Employee.ToList();
        }
        public int AddEmployee(Employee employee)
        {
            _context.Employee.Add(employee);
            _context.SaveChanges();
            return employee.ID;
        }

        public Employee GetEmployee(int Id)
        {
            return _context.Employee.Find(Id);
            //return _context.Employee.Where{ a->a.ID == Id).FirstOrDefault;
        }

        public int DeleteEmployee(int Id)
        {
            _context.Employee.Remove(GetEmployee(Id));
            _context.SaveChanges();
            return 1;
        }

        public int UpdateEmployee(Employee employee)
        {
            _context.Entry(employee).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
            return 1;
        }
    }
}
