﻿create table Employee
(ID int primary key identity,
Name varchar(50),
DOJ datetime,
DepartmentID int)

select * from Employee

insert into Employee values('Ryan Bell', '1/20/99', 1)